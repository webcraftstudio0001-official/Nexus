export { Translator } from './RemainingPages'
