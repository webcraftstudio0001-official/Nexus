export { Dictionary } from './RemainingPages'
